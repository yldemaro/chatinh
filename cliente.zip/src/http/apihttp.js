const baseUrl= "http://localhost:5555/api";



export const db = baseUrl;