<script >

import {
    ref,
    uploadBytes,
    getStorage,
    getDownloadURL,
    deleteObject,
} from "firebase/storage";

import { storage } from '../firebase';
import { db } from '../http/apihttp';

// import baseUrl from '../http/apihttp';
export default {

    data() {
        return {
            // baseurl: 'http://localhost:5555/api',
            username: '',
            password: '',
            email: '',
            mostraBox: true,
            userSuperAdmin: {},
            usersAll: [],
            groupsAll: [],
            name: '',
            img: '',
            img2: '',
            mostrarUsuarios: true,
            mostrarGrupos: false,
            profile: {},
            mostrarLink: false
        }
    },
    created() {
        // console.log(db)
        this.logueado();
    },
    methods: {
        logueado() {
            this.profile = JSON.parse(localStorage.getItem('profile'));
            // console.log(this.profile);

            if (this.profile) {
                this.getAllUsers();
                this.getAllRooms();
                this.mostraBox = false;
            } else {
                localStorage.clear();
                this.mostraBox = true;
            }

        },
        getAllUsers() {
            setInterval(() => {
                fetch(`${db}/client/users`, {
                    method: "GET"
                })
                    .then(response => response.json())
                    .then(data => {
                        // console.log(data)
                        this.usersAll = data;
                    })
            }, 4000)
        },
        getAllRooms() {
            // setInterval(() => {
            fetch(`${db}/client/rooms`, {
                method: "GET"
            })
                .then(response => response.json())
                .then(data => {
                    // console.log(data)
                    if (!data) {
                        return;
                    } else {
                        this.groupsAll = data;
                    }

                })
            // }, 4000)
        },
        onSubmit(e) {
            e.preventDefault();
            // console.log(this.username, this.password);
            const value = {
                username: this.username,
                password: this.password
            }
            fetch(`${db}/auth/signin`, {
                method: 'POST',
                body: JSON.stringify(value)
            })
                .then(response => response.json())
                .then(async data => {
                    this.mostraBox = false;
                    // console.log(data);
                    this.userSuperAdmin = await data;
                    localStorage.setItem("profile", JSON.stringify(data))

                    this.getAllUsers();

                    this.username = '';
                    this.password = '';
                })
        },
        async agregarAdmin(e) {
            e.preventDefault();
            const value = {
                UID: "",
                Username: this.username,
                Password: this.password,
                Email: this.email,
                plane: this.password,
                img: "",
                role: "admin",
                owner: this.userSuperAdmin.User?.oid,
            };
            const imageRef = ref(storage, value.Username);

            // uploadBytes(imageRef, this.img2)
            //     .then(() => {
            //         getDownloadURL(imageRef).then(async (url) => {
            // value.img = await url || "user.svg";

            await fetch(`${db}/auth/signup`, {
                method: "POST",
                body: JSON.stringify(value)
            }).then(response => response.json())
                .then(async data => {
                    // console.log(data);
                    const value = {
                        uid: null,
                        name: this.username,
                        alias: "",
                        staff: [
                            this.username
                        ],
                        members: [
                            this.username
                        ],
                        img: "",
                        status: false
                    }
                    if (data) {
                        await fetch(`${db}/client/rooms`, {
                            method: 'POST',
                            body: JSON.stringify(value)
                        })
                            .then(response => response.json())
                            .then(async data => {
                                // console.log(data);
                                const value = {
                                    Username: this.username,
                                    Room: data.oid
                                }
                                // console.log(value)
                                // if (data) {
                                await fetch(`${db}/client/links/generate`, {
                                    method: 'POST',
                                    body: JSON.stringify(value)
                                }).then(response => response.json())
                                    .then(data => {
                                        // console.log(data)
                                        // this.link = data.link;
                                        alertify.alert("Usuario Creado", `${data.link}/${data.username}`)

                                    })
                                // }
                            })
                    }
                })


            // })
            // })


        },
        handleImage(e) {
            if (e.target.files[0]) {
                this.img2 = e.target.files[0].name;
                const data = URL.createObjectURL(e.target.files[0]);
                this.img = data;
            }
        },
        users() {
            this.mostrarUsuarios = !this.mostrarUsuarios;
            this.mostrarGrupos = false
        },
        grupos() {
            this.mostrarGrupos = !this.mostrarGrupos
            this.mostrarUsuarios = false;
            // this.mostrarUsuarios = false;
        },
        logout() {
            localStorage.clear();
            this.mostraBox = true;
        },
        eliminarRoom(id) {
            // console.log(id);
            fetch(`${db}/client/users/${id}`, {
                method: 'DELETE'
            })
                .then(response => response.json())
                .then(data => {
                    // console.log(data)
                    alertify.alert(data.message)
                })
        },
        eliminarUser(id) {
            // console.log(id);
            fetch(`${db}/client/users/${id}`, {
                method: 'DELETE'
            })
                .then(response => response.json())
                .then(data => {
                    // console.log(data)
                    alertify.alert(data.message)
                })
        }
    }
}

</script>

<template>
    <div class="container container-superadmin" v-if="mostraBox">
        <div class="box-superadmin p-2">
            <div class="form-group">
                <label class="sr-only" for="inlineFormInputGroup">Username</label>
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <div class="input-group-text">@</div>
                    </div>
                    <input type="text" class="form-control" v-model="username" id="inlineFormInputGroup"
                        placeholder="Username">
                </div>
            </div>
            <div class="form-group">
                <label class="sr-only" for="password">Password</label>
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <div class="input-group-text">@</div>
                    </div>
                    <input type="password" class="form-control" v-model="password" name="password" placeholder="Password">
                </div>

            </div>
            <div class="text-center mt-1">
                <button type="submit" class="btn btn-success text-dark" @click="onSubmit($event)">Iniciar Sesión</button>
            </div>
        </div>

    </div>
    <div class="container container-superadmin2 p-3" v-if="!mostraBox">

        <div>
            <!-- Button trigger modal -->
            <div class="row mb-3 p-2 bg bg-secondary">
                <div class="col-md-3 p-2">
                    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Agregar Administrador
                    </button>
                </div>
                <div class="col-md-7 p-2">
                    <button type="button" class="btn btn-dark mr-3" @click="users()">
                        Mostrar Usuarios
                    </button>
                    <button type="button" class="btn btn-dark" @click="grupos()">
                        Mostrar Grupos
                    </button>
                </div>
                <div class="col-md-2 p-2">
                    <button type="button" class="btn btn-danger mr-3" @click="logout()">
                        Logout
                    </button>
                </div>
            </div>

            <table class="table bg bg-light text-center" style="table-layout: fixed; font-size:15px;">
                <thead v-if="mostrarUsuarios">
                    <tr>
                        <th>NAME</th>
                        <th>EMAIL</th>
                        <th>ROL</th>
                        <th>IMAGE</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody v-if="mostrarUsuarios">
                    <tr v-for="(item, index) in usersAll" :key="item.objectId">
                        <td>{{ item.username }}</td>
                        <td>{{ item.email }}</td>
                        <td>{{ item.role }}</td>
                        <td v-if="item.img == ''"><img style="width:32px; margin:auto;" src="../assets/img/user.svg"
                                alt="" /></td>
                        <td v-if="item.img != ''"> <img style="width:32px; margin:auto;" :src="item.img" alt="" /></td>
                        <td><button @click="eliminarUser(item.objectId)" :disabled="item.username == profile.User.username"
                                class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></td>
                    </tr>
                    <tr class="text-center" v-if="usersAll.length === 0">
                        <td colspan="12">Cargando......</td>
                    </tr>
                </tbody>
                <thead v-if="mostrarGrupos">
                    <tr>
                        <th>NAME</th>
                        <th>STAFF</th>
                        <th>MEMBERS</th>
                        <th>IMAGE</th>
                        <th>LINKS</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody v-if="mostrarGrupos">
                    <tr v-for="(item, index) in groupsAll" :key="item.objectId">
                        <td>{{ item.name }}</td>
                        <td>{{ item.staff }}</td>
                        <td>{{ item.members.join(',') }}</td>
                        <td v-if="item.img == ''"><img style="width:32px; margin:auto;" src="../assets/img/user.svg"
                                alt="" /></td>
                        <td v-if="item.img != ''"> <img style="width:32px; margin:auto;" :src="item.img" alt="" /></td>
                        <td>{{ item.link }}</td>
                        <td> <button class="btn btn-danger" @click="eliminarRoom(item.objectId)"><i
                                    class="fa-solid fa-trash"></i></button></td>
                    </tr>
                    <tr class="text-center" v-if="groupsAll.length === 0">
                        <td colspan="12">No Existe Grupos</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div v-if="mostrarLink">
            <div class="card">
                <div class="card-body">
                    <p>{{ link }}</p>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg bg-primary text-white">
                        <h5 class="modal-title" id="staticBackdropLabel">Agregar Usuario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" v-model="username" name="name" placeholder="Username">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" v-model="password" name="password"
                                placeholder="Password">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" v-model="email" name="email" placeholder="Email">
                        </div>
                        <div class="form-group">
                            <input type="file" className="mb-2" class="form-control" @change="handleImage($event)" />
                            <div className="text-center p-4" v-if="img != ''">
                                <img style="width: 100px; height: 100px; margin: auto;" :src="img" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal"
                            @click="agregarAdmin($event)">Agregar</button>
                    </div>
                </div>
            </div>
        </div>


    </div>
</template>

<style>
.container-superadmin {
    background-image: url("../assets/img/caballos.jpg");
    background-size: 100% 100%;
    background-position: center;
    height: 100vh;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.container-superadmin2 {
    background-image: url("../assets/img/caballos.jpg");
    background-size: 100% 100%;
    background-position: center;
    height: 100vh;
    width: 100%;
}

.box-superadmin {
    background: white;
    height: 280px;
    width: 280px;
    max-width: 280px;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    flex-direction: column;
}

@media (max-width: 480px) {
    .row {
        text-align: center;
    }
}
</style>